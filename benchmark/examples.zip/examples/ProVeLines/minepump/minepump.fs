# minepump feature space

MinePump
WaterSensor
High
Low
Normal
Command
Start
Stop
MethaneSensor
MethaneAlarm
MethaneQuery