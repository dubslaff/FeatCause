# LowerBounds:250,275,300,325,350,375,400,425,450,475,500,525,550,575,600,625,650,675,700,725,750,775,800,825
root
no_asm
no_8x8dct
no_cabac
no_deblock
no_fast_pskip
no_mbtree
no_mixed_refs
no_weightb
rc_lookahead
rc_lookahead_20
rc_lookahead_40
rc_lookahead_60
ref
ref_1
ref_5
ref_9