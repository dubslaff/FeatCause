# LowerBounds:200000,300000,400000,500000,600000,700000,800000,900000,1000000,1100000,1200000,1300000,1400000,1500000,1600000,1700000,1800000,1900000,2000000,2100000,2200000,2300000,2400000,2500000
# Epsilon:0.0
root
encryption
compression
compressionBzip2
compressionGzip
compressionLzo
compressionZpaq
compressionLrzip
level
level1
level2
level3
level4
level5
level6
level7
level8
level9
unlimitedWindowSize
disableCompressibilityTesting