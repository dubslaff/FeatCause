# a simple hack to run ProVeLines and generate DNF effects that FeatCause understands
# for strange reasons it does only work without explicit providing the provelines dictionary

import argparse
import re
import shlex
import subprocess

vars_rex = re.compile('Variables:.*')
prop_rex = re.compile('Model checking: filter\(printall, .*')
result_rex = re.compile('[0-9]*:\(.*')
end_rex = re.compile('Time for model checking:.*')


# main program
if __name__ == '__main__':
	# define input arguments for the extractor script
	argparser = argparse.ArgumentParser(description="Prism Extract - generate DNF effects for FeatCause")
	argparser.add_argument("experiment", help="path to the experiment containing the log (.log) and feature space (.fs), e.g., ./advanced/BSN")
	args = argparser.parse_args()
	experiment = args.experiment

	# first read feature variables
	feats = set()
	with open(experiment + ".fs", "r") as l:
		for line in l:
			line = line.replace("\n", "")
			feats.add(line)

	# then the log
	with open(experiment+".log", "r") as log:
		d_feats = dict() # dictionary to map positions to features
		m_feats = dict() # dictionary of features to [min0/max0/min1/max1]
		thresholds = [0.019, 0.020, 0.022, 0.025, 0.029, 0.034, 0.04]
		s = dict()
		for i in range(len(thresholds)):
			s[i] = ""
		step = 0
		for lline in log:
			if result_rex.match(lline):
				rlist = re.split('\(|,|\)|=|\n', lline)[1:]
				t = float(rlist[-2])
				clist = list()
				for k in d_feats.keys():
					if rlist[k] == '1':
						clist.append(d_feats[k])
						m_feats[d_feats[k]][1] = max(m_feats[d_feats[k]][1], t)
					elif rlist[k] == '0':
						clist.append("~"+ d_feats[k])
						m_feats[d_feats[k]][0] = min(m_feats[d_feats[k]][0], t)
				fconfs = " & ".join(clist)+"\n"
				for i in range(len(thresholds)):
					# comment out the property
					if t < thresholds[i]:
						with open(experiment+"."+str(i), "a") as ef:
							ef.write(fconfs)
			elif prop_rex.match(lline):
				p = lline.split(",")
				for i in range(len(thresholds)):
					# comment out the property
					with open(experiment+"."+str(i), "w") as ef:
						ef.write("# " + str(thresholds[i]) + p[1] + "\n\n")
			elif vars_rex.match(lline):
				# build directory of feature variables
				lline = lline.replace(" \n", "")
				lline = lline.replace("Variables:   ", "")
				v = lline.split(" ")
				for k in range(len(v)):
					if v[k].startswith("_"):
						if v[k][1:] in feats: # need to strip heading _ (by ProFeat)
							v[k] = v[k][1:]
						d_feats[k] = v[k]
						m_feats[v[k]] = [1,0] # initialize min/max
			step += 1
			print(step, end="\r")
		with open(experiment+".mm", "w") as ef:
			for k in d_feats.keys():
				ef.write(d_feats[k] + ": "+",".join(map(str, m_feats[d_feats[k]]))+"\n")